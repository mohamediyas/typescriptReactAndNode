import { createConnection, getManager } from "typeorm";
import faker from "faker";
import { randomInt } from "crypto";
import { Order } from "../entity/order.entity";
import { OrderItem } from "../entity/orderItem.entity";

createConnection().then(async (connection) => {
  const repository = getManager().getRepository(Order);
  const orderItemrepo = getManager().getRepository(OrderItem);

  for (let i = 0; i < 30; i++) {
    const order = await repository.save({
      firstName: faker.name.firstName(),
      lastName: faker.name.lastName(),
      email: faker.internet.email(),
    });

    for (let j = 0; j < randomInt(1, 5); j++) {
      await orderItemrepo.save({
        order,
        productTitle: faker.lorem.words(2),
        price: randomInt(10, 100),
        quantity: randomInt(1, 5),
      });
    }
  }

  process.exit(0);
});
