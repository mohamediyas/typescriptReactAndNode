import { createConnection, getManager } from "typeorm";
import { Permission } from "../entity/permission.entity";
import { Role } from "../entity/role.entity";


createConnection().then(async connection=>{

    const permissionRepository = getManager().getRepository(Permission)


    const perms = ['view_users','edit_users','view_roles','edit_roles','view_products','edit_products','view_orders','edit_orders']

    let permission =[]

    for(let i=0; i< perms.length;i++){
     permission.push( await permissionRepository.save({
            name:perms[i]
        }))
    }


    const roleRepository = getManager().getRepository(Role)

    await roleRepository.save({
        name:'Admin',
        permissions:permission
    })

    delete permission[3]

    await roleRepository.save({
        name:'Editor',
        permissions:permission

    })

    delete permission[1]
    delete permission[5]
    delete permission[7]

    await roleRepository.save({
        name:'viewer',
        permissions:permission


    })


    process.exit(0)

})