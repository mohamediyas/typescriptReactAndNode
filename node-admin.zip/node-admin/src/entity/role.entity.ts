import { Column, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Permission } from "./permission.entity";

@Entity()
export class Role{
    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    name:string;

    @ManyToMany(()=>Permission)
    @JoinTable({name:'role_permissions',joinColumn: {name:'roleId',referencedColumnName:'id'},inverseJoinColumn:{name:'permissionId',referencedColumnName:'id'}})
    permissions:Permission[]

}