import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Role } from "./role.entity";

@Entity()
export class User{
    @PrimaryGeneratedColumn()

    id:number;

    @Column()

    firstName:string;

    @Column()

    lastName:string;

    @Column({
        unique:true
    })

    email:string;

    @Column()
 
    password:string;

    @ManyToOne(()=>Role)
    @JoinColumn({name:'roleId'})
    role:Role;


}