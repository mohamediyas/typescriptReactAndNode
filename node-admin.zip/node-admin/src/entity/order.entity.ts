import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { OrderItem } from "./orderItem.entity";

@Entity()
export class Order {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  firstName: string;

  @Column()
  lastName: string;
  @Column()
  email: string;
  @CreateDateColumn()
  createdAt: string;

  @OneToMany(() => OrderItem, (orderItem) => orderItem.order)
  orderItem: OrderItem[];

  get name(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  get total(): number {
    return this.orderItem.reduce(
      (sum, item) => sum + item.quantity * item.price,
      0
    );
  }
}
