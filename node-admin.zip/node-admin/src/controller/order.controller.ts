import { Request, Response } from "express";
import { Parser } from "json2csv";
import { getManager } from "typeorm";
import { Order } from "../entity/order.entity";

export const Orders = async (req: Request, res: Response) => {
  const take = 15;

  const page = parseInt((req.query.page as string) || "1");

  const repository = getManager().getRepository(Order);

  const [data, total] = await repository.findAndCount({
    take,
    skip: (page - 1) * take,
    relations: ["orderItem"],
  });

  res.send({
    data: data.map((order) => ({
      id: order.id,
      name: order.name,
      email: order.email,
      total: order.total,
      createdAt: order.createdAt,
      orderItems: order.orderItem,
    })),
    meta: {
      total,
      page,
      lastPage: Math.ceil(total / take),
    },
  });
};

export const Export = async (req: Request, res: Response) => {
  const parser = new Parser({
    fields: ["ID", "Name", "Email", "Product Title", "Price", "Quantity"],
  });

  const repository = getManager().getRepository(Order);

  const orders = await repository.find({ relations: ["orderItem"] });

  const json = [];

  orders.forEach((order) => {
    json.push({
      ID: order.id,
      Name: order.name,
      Email: order.email,
      "Product Title": "",
      Price: "",
      Quantity: "",
    });

    order.orderItem.forEach((orderItem) => {
      json.push({
        ID: "",
        Name: "",
        Email: "",
        "Product Title": orderItem.productTitle,
        Price: orderItem.price,
        Quantity: orderItem.quantity,
      });
    });
  });

  const csv = parser.parse(json);

  res.header("Content-Type", "text/csv");

  res.attachment("orders.csv");

  res.send(csv);
};

export const Chart = async (req: Request, res: Response) => {
  const manger = getManager();

  const result = await manger.query(
    ` SELECT date_format(o.createdAt,'%Y-%m-%d') as date,SUM(oi.price*oi.quantity) as sum FROM node_admin.order o JOIN order_item oi on o.id = oi.orderId GROUP BY date`
  );

  res.send(result);
};
