import express, { Router } from "express";
import multer from "multer";
import {
  AuthenticatedUser,
  Login,
  Logout,
  Register,
  UpdateInfo,
  UpdatePassword,
} from "./controller/auth.controller";
import { Upload } from "./controller/image.controller";
import { Permissions } from "./controller/permission.controller";
import {
  CreateProduct,
  DeleteProduct,
  GetProduct,
  Products,
  updateProduct,
} from "./controller/product.controller";
import {
  CreateRole,
  DeleteRole,
  GetRole,
  Roles,
  UpdateRole,
} from "./controller/role.controller";
import {
  CreateUser,
  DeleteUser,
  GetUser,
  updateUser,
  Users,
} from "./controller/user.controller";
import { AuthMiddleware } from "./middleware/auth.middleware";
import { extname } from "path";
import { Chart, Export, Orders } from "./controller/order.controller";
import { PermissionMiddleware } from "./middleware/permission.middleware";

// const router = express.Router()

export const routes = (router: Router) => {
  // auth
  router.post("/api/register", Register);

  router.post("/api/login", Login);

  router.get("/api/user", AuthMiddleware, AuthenticatedUser);

  router.post("/api/logout", AuthMiddleware, Logout);

  router.put("/api/users/info", AuthMiddleware, UpdateInfo);

  router.put("/api/users/password", AuthMiddleware, UpdatePassword);

  // user

  router.get(
    "/api/users",
    AuthMiddleware,
    PermissionMiddleware("users"),
    Users
  );

  router.post(
    "/api/users",
    AuthMiddleware,
    PermissionMiddleware("users"),
    CreateUser
  );

  router.get(
    "/api/users/:id",
    AuthMiddleware,
    PermissionMiddleware("users"),
    GetUser
  );

  router.put(
    "/api/users/:id",
    AuthMiddleware,
    PermissionMiddleware("users"),
    updateUser
  );

  router.delete(
    "/api/users/:id",
    AuthMiddleware,
    PermissionMiddleware("users"),
    DeleteUser
  );

  // permission

  router.get("/api/permissions", AuthMiddleware, Permissions);

  // role
  router.get(
    "/api/roles",
    AuthMiddleware,
    PermissionMiddleware("roles"),
    Roles
  );
  router.post(
    "/api/roles",
    AuthMiddleware,
    PermissionMiddleware("roles"),
    CreateRole
  );
  router.get(
    "/api/roles/:id",
    AuthMiddleware,
    PermissionMiddleware("roles"),
    GetRole
  );
  router.put(
    "/api/roles/:id",
    AuthMiddleware,
    PermissionMiddleware("roles"),
    UpdateRole
  );
  router.delete(
    "/api/roles/:id",
    AuthMiddleware,
    PermissionMiddleware("roles"),
    DeleteRole
  );

  // products

  router.get(
    "/api/products",
    AuthMiddleware,
    PermissionMiddleware("products"),
    Products
  );

  router.post(
    "/api/products",
    AuthMiddleware,
    PermissionMiddleware("products"),
    CreateProduct
  );

  router.get(
    "/api/products/:id",
    AuthMiddleware,
    PermissionMiddleware("products"),
    GetProduct
  );

  router.put(
    "/api/products/:id",
    AuthMiddleware,
    PermissionMiddleware("products"),
    updateProduct
  );

  router.delete(
    "/api/products/:id",
    AuthMiddleware,
    PermissionMiddleware("products"),
    DeleteProduct
  );

  //  images

  router.post("/api/upload", AuthMiddleware, Upload);

  // public

  router.use("/api/uploads", express.static("./uploads"));

  // orders

  router.get("/api/orders", AuthMiddleware, Orders);

  router.post("/api/export", AuthMiddleware, Export);

  router.get("/api/chart", AuthMiddleware, Chart);
};
