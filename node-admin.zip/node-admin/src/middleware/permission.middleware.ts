import { Request, Response } from "express";

export const PermissionMiddleware = (accessor: string) => {
  return async (req: Request, res: Response, next: Function) => {
    const user = req["user"];

    const permissions = user.role.permissions;

    if (req.method == "GET") {
      if (
        !permissions.some(
          (p) => p.name == `view_${accessor}` || p.name == `edit_${accessor}`
        )
      ) {
        return res.send(401).send("unautherized");
      }
    } else {
      if (!permissions.some((p) => p.name == `edit_${accessor}`)) {
        return res.send(401).send("unautherized");
      }
    }

    next();
  };
};
