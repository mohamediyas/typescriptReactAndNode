import axios from "axios";
import React from "react";

const ImageUpload = (props: any) => {
  const upload = async (files) => {
    if (files == null) return;

    const formData = new FormData();

    formData.append("image", files[0]);

    const { data } = await axios.post(
      `http://localhost:8000/api/upload`,
      formData,
      { withCredentials: true }
    );

    props.uploaded(data.url);
  };

  return (
    <label className="btn btn-primary">
      Upload{" "}
      <input onChange={(e) => upload(e.target.files)} type="file" hidden />
    </label>
  );
};

export default ImageUpload;
