import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { User } from "../models/user";

const Nav = () => {
  const [user, setUser] = useState<any>(new User());

  useEffect(() => {
    const getUser = async () => {
      const { data } = await axios.get("http://localhost:8000/api/user", {
        withCredentials: true,
      });

      setUser(
        new User(data.id, data.firstName, data.lastName, data.email, data.role)
      );

      console.log(data);
    };

    getUser();
  }, []);

  const logout = async () => {
    const response = await axios.post(
      "http://localhost:8000/api/logout",
      {},
      { withCredentials: true }
    );

    console.log(response);
  };

  return (
    <div>
      <header className="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a className="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">
          Company name
        </a>

        <div className="navbar-nav">
          <div className="nav-item text-nowrap">
            <Link
              to={"/profile"}
              className="nav-link px-3 text-decoration-none"
              href="#"
            >
              {user && user.name}
            </Link>
          </div>
          <div className="nav-item text-nowrap">
            <Link
              to={"/login"}
              className="nav-link px-3"
              href="#"
              onClick={logout}
            >
              Sign out
            </Link>
          </div>
        </div>
      </header>
    </div>
  );
};

export default Nav;
