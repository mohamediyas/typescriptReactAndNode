import React from "react";

const Paginator = (props: any) => {
  const next = () => {
    if (props.page < props.lastPage) {
      props.setPage((page) => page + 1);
    }
  };

  const previous = () => {
    if (props.page > 1) {
      props.setPage((page) => page - 1);
    }
  };

  return (
    <div>
      <nav>
        <ul className="pagination">
          <li className="page-item">
            <a className="page-link" onClick={previous}>
              Previous
            </a>
          </li>
          <li className="page-item">
            <a className="page-link" onClick={next}>
              Next
            </a>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Paginator;
