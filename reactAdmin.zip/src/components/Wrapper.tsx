import axios from "axios";
import React, { useEffect, useState } from "react";
import { Redirect } from "react-router-dom";
import Menu from "./Menu";
import Nav from "./Nav";

import { useDispatch, useSelector } from "react-redux";
import { setUser } from "../redux/actions/setUserAction";

const Wrapper = (props: any) => {
  const [redirect, setRedirect] = useState(false);

  const state = useSelector((state: any) => state.user);

  console.log(state);

  const dispatch = useDispatch();

  useEffect(() => {
    const getUser = async () => {
      try {
        const { data } = await axios.get("http://localhost:8000/api/user", {
          withCredentials: true,
        });

        dispatch(setUser(data));

        console.log(data);
      } catch (error) {
        setRedirect(true);
      }
    };

    getUser();
  }, []);

  if (redirect) {
    return <Redirect to={"/login"} />;
  }

  return (
    <div>
      <Nav />
      <div className="container-fluid">
        <div className="row">
          <Menu />

          <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            {props.children}
          </main>
        </div>
      </div>
    </div>
  );
};

export default Wrapper;
