import React from "react";
import { Link, NavLink } from "react-router-dom";

const Menu = () => {
  return (
    <div>
      <nav
        id="sidebarMenu"
        className="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse"
      >
        <div className="position-sticky pt-3">
          <ul className="nav flex-column">
            <li className="nav-item">
              <NavLink
                exact
                to={"/"}
                className="nav-link"
                aria-current="page"
                href="#"
              >
                <span data-feather="home"></span>
                Dashboard
              </NavLink>
            </li>
            <li>
              <NavLink
                to={"/users"}
                className="nav-link "
                aria-current="page"
                href="#"
              >
                <span data-feather="home"></span>
                Users
              </NavLink>
            </li>
            <li>
              <NavLink
                to={"/roles"}
                className="nav-link "
                aria-current="page"
                href="#"
              >
                <span data-feather="home"></span>
                Roles
              </NavLink>
            </li>
            <li>
              <NavLink
                to={"/products"}
                className="nav-link "
                aria-current="page"
                href="#"
              >
                <span data-feather="home"></span>
                Products
              </NavLink>
            </li>
            <li>
              <NavLink
                to={"/orders"}
                className="nav-link "
                aria-current="page"
                href="#"
              >
                <span data-feather="home"></span>
                Orders
              </NavLink>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default Menu;
