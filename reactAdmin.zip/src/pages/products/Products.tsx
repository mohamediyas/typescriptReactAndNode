import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Paginator from "../../components/Paginator";
import Wrapper from "../../components/Wrapper";

interface Product {
  id: number;
  title: string;
  description: string;
  image: string;
  price: number;
}

const Products = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [page, setPage] = useState(1);
  const [lastPage, setLastPage] = useState(0);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await axios.get(
        `http://localhost:8000/api/products?page=${page}`,
        {
          withCredentials: true,
        }
      );

      setProducts(data.data);
      setLastPage(data.meta.lastPage);
    };

    fetchProducts();
  }, [page]);

  console.log(products);

  const del = async (id: number) => {
    if (window.confirm("Are you sure to delete ?")) {
      await axios.delete(`http://localhost:8000/api/products/${id}`, {
        withCredentials: true,
      });

      setProducts(products.filter((p) => p.id != id));
    }
  };

  return (
    <Wrapper>
      <Link
        to={"/products/create"}
        className="btn btn-sm btn-outline-secondary"
      >
        Add
      </Link>
      <div className="table-responsive">
        <table className="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Image</th>
              <th scope="col">Title</th>
              <th scope="col">Description</th>
              <th scope="col">Price</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => {
              return (
                <tr key={p.id}>
                  <td>{p.id}</td>
                  <td>
                    <img src={p.image} width="50" />{" "}
                  </td>
                  <td>{p.title}</td>
                  <td>{p.description}</td>
                  <td>{p.price}</td>
                  <td>
                    <div className="btn-group mr-2">
                      <Link
                        to={`/products/${p.id}/edit`}
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Edit
                      </Link>
                      <a
                        href="#"
                        onClick={() => del(p.id)}
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Delete
                      </a>
                    </div>
                  </td>{" "}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Paginator lastPage={lastPage} setPage={setPage} page={page} />
    </Wrapper>
  );
};

export default Products;
