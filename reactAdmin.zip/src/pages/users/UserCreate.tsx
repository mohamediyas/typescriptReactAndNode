import axios from "axios";
import React, { SyntheticEvent, useEffect, useState } from "react";
import { Redirect } from "react-router-dom";
import Wrapper from "../../components/Wrapper";

interface Role {
  id: number;
  name: string;
}

const UserCreate = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [roleId, setRoleId] = useState("");
  const [roles, setRolse] = useState<Role[]>([]);

  const [redirect, setRedirect] = useState(false);

  useEffect(() => {
    const fetchRole = async () => {
      const { data } = await axios.get("http://localhost:8000/api/roles", {
        withCredentials: true,
      });

      setRolse(data);
    };

    fetchRole();
  }, []);

  const submit = async (e: SyntheticEvent) => {
    e.preventDefault();

    await axios.post(
      `http://localhost:8000/api/users`,
      {
        firstName,
        lastName,
        email,
        roleId,
      },
      {
        withCredentials: true,
      }
    );

    setRedirect(true);
  };

  if (redirect) {
    return <Redirect to={"/users"} />;
  }

  return (
    <Wrapper>
      <form onSubmit={submit}>
        <div className="mb-3">
          <label>First Name</label>
          <input
            className="form-control"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />
        </div>{" "}
        <div className="mb-3">
          <label>Last Name</label>
          <input
            className="form-control"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </div>{" "}
        <div className="mb-3">
          <label>Email</label>
          <input
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label>Roles</label>
          <select
            className="form-control"
            // value={roleId}
            onChange={(e) => setRoleId(e.target.value)}
          >
            {roles.map((role) => {
              return (
                <option key={role.id} value={role.id}>
                  {role.name}
                </option>
              );
            })}
          </select>
        </div>
        <button className="btn btn-outline-secondary">Save</button>
      </form>
    </Wrapper>
  );
};

export default UserCreate;
