import axios from "axios";
import React, { SyntheticEvent, useEffect, useState } from "react";
import { Redirect } from "react-router-dom";
import Wrapper from "../../components/Wrapper";

interface Role {
  id: number;
  name: string;
}

const UserEdit = (props: any) => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [roleId, setRoleId] = useState("");
  const [roles, setRolse] = useState<Role[]>([]);

  const [redirect, setRedirect] = useState(false);

  let id: number;

  useEffect(() => {
    const fetchRole = async () => {
      const response = await axios.get("http://localhost:8000/api/roles", {
        withCredentials: true,
      });

      setRolse(response.data);

      id = props.match.params.id;

      const { data } = await axios.get(
        `http://localhost:8000/api/users/${id}`,
        { withCredentials: true }
      );

      console.log("IMTHIYAS", data);

      setFirstName(data.firstName);
      setLastName(data.lastName);
      setEmail(data.email);
      setRoleId(data.role.id);
    };

    fetchRole();
  }, []);

  const submit = async (e: SyntheticEvent) => {
    e.preventDefault();

    await axios.put(
      `http://localhost:8000/api/users/${props.match.params.id}`,
      {
        firstName,
        lastName,
        email,
        roleId,
      },
      {
        withCredentials: true,
      }
    );

    setRedirect(true);
  };

  if (redirect) {
    return <Redirect to={"/users"} />;
  }

  return (
    <Wrapper>
      <form onSubmit={submit}>
        <div className="mb-3">
          <label>First Name</label>
          <input
            className="form-control"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />
        </div>{" "}
        <div className="mb-3">
          <label>Last Name</label>
          <input
            className="form-control"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </div>{" "}
        <div className="mb-3">
          <label>Email</label>
          <input
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label>Roles</label>
          <select
            className="form-control"
            value={roleId}
            onChange={(e) => setRoleId(e.target.value)}
          >
            {roles.map((role) => {
              return (
                <option key={role.id} value={role.id}>
                  {role.name}
                </option>
              );
            })}
          </select>
        </div>
        <button className="btn btn-outline-secondary">Save</button>
      </form>
    </Wrapper>
  );
};

export default UserEdit;
