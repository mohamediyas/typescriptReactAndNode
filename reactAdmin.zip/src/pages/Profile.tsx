import axios from "axios";
import React, { SyntheticEvent, useEffect, useState } from "react";
import Wrapper from "../components/Wrapper";

const Profile = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");

  useEffect(() => {
    const fetchUser = async () => {
      const { data } = await axios.get(`http://localhost:8000/api/user`, {
        withCredentials: true,
      });

      setFirstName(data.firstName);
      setLastName(data.lastName);
      setEmail(data.email);
    };

    fetchUser();
  }, []);

  const infoSubmit = async (e: SyntheticEvent) => {
    e.preventDefault();

    await axios.put(
      `http://localhost:8000/api/users/info`,
      {
        firstName,
        lastName,
        email,
      },
      {
        withCredentials: true,
      }
    );
  };

  const passwordSubmit = async (e: SyntheticEvent) => {
    e.preventDefault();

    await axios.put(
      `http://localhost:8000/api/users/password`,
      {
        password,
        passwordConfirm,
      },
      {
        withCredentials: true,
      }
    );
  };

  return (
    <Wrapper>
      <h3>Account Information</h3>
      <form onSubmit={infoSubmit}>
        <div className="mb-3">
          <label>First Name</label>
          <input
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Last Name</label>
          <input
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Email</label>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="form-control"
          />
        </div>
        <button className="btn btn-outline-secondary">Save</button>
      </form>

      <h3 className="mt-4">Change Password</h3>
      <form onSubmit={passwordSubmit}>
        <div className="mb-3">
          <label>Password</label>
          <input
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            className="form-control"
          />
        </div>

        <div className="mb-3">
          <label>Password Confirm</label>
          <input
            onChange={(e) => setPasswordConfirm(e.target.value)}
            type="password"
            className="form-control"
          />
        </div>

        <button className="btn btn-outline-secondary">Save</button>
      </form>
    </Wrapper>
  );
};

export default Profile;
