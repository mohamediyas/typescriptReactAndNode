import React, { SyntheticEvent, useState } from "react";
import axios from "axios";
import { Redirect } from "react-router-dom";

interface State {
  email: string;
  password: string;
}

const Login = () => {
  const [state, setState] = useState<State>({
    email: "",
    password: "",
  });

  const [redirect, setDirect] = useState(false);

  const submit = async (e: SyntheticEvent) => {
    const { email, password } = state;

    e.preventDefault();

    const response = await axios.post(
      "http://localhost:8000/api/login",
      {
        email,
        password,
      },
      { withCredentials: true }
    );

    setDirect(true);
    console.log(response.data);
  };

  if (redirect) {
    return <Redirect to={"/"} />;
  }

  return (
    <div className="text-center">
      <main className="form-signin">
        <form onSubmit={submit}>
          <h1 className="h3 mb-3 fw-normal">Please sign in</h1>

          <div className="form-floating">
            <input
              type="email"
              className="form-control"
              id="floatingInput"
              placeholder="example@gmail.com"
              required
              value={state.email}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  email: e.target.value,
                }))
              }
            />
            <label>Email</label>
          </div>
          <div className="form-floating">
            <input
              type="password"
              className="form-control"
              id="floatingPassword"
              placeholder="Password"
              value={state.password}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  password: e.target.value,
                }))
              }
            />
            <label>Password</label>
          </div>

          <button className="w-100 btn btn-lg btn-primary" type="submit">
            Submit
          </button>
        </form>
      </main>
    </div>
  );
};

export default Login;
