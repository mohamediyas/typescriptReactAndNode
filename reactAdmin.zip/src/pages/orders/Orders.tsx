import axios from "axios";
import React, { useEffect, useState } from "react";
import Paginator from "../../components/Paginator";
import Wrapper from "../../components/Wrapper";

const hide = {
  maxHeight: 0,
  transition: "1000ms ease-in",
};
const show = {
  maxHeight: "150px",
  transition: "1000ms ease-out",
};

interface Orderss {
  id: number;
  name: string;
  email: string;
  total: number;
  orderItems: OrderItems[];
}
interface OrderItems {
  id: number;
  productTitle: string;
  price: number;
  quantity: number;
}

const Orders = () => {
  const [orders, setOrders] = useState<Orderss[]>([]);
  const [page, setPage] = useState(1);
  const [lastPage, setLastPage] = useState(0);
  const [selected, setSelected] = useState(0);

  useEffect(() => {
    const fetchUser = async () => {
      const { data } = await axios.get(
        `http://localhost:8000/api/orders?page=${page}`,
        {
          withCredentials: true,
        }
      );

      setOrders(data.data);
      setLastPage(data.meta.lastPage);
    };

    fetchUser();
  }, [page]);

  const select = (id) => {
    setSelected(selected == id ? 0 : id);
  };

  const handleExport = async () => {
    const { data } = await axios.post(
      `http://localhost:8000/api/export`,
      {},
      {
        withCredentials: true,
        responseType: "blob",
      }
    );

    const blob = new Blob([data], { type: "text/csv" });

    const url = window.URL.createObjectURL(data);

    const link = document.createElement("a");

    link.href = url;

    link.download = "orders.csv";

    link.click();
  };

  return (
    <Wrapper>
      <a
        onClick={handleExport}
        href="#"
        className="btn btn-sm btn-outline-secondary"
      >
        Export
      </a>
      <div className="table-responsive">
        <table className="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Total</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => {
              return (
                <>
                  {" "}
                  <tr key={order.id}>
                    <td>{order.id}</td>
                    <td>{order.name}</td>
                    <td>{order.email}</td>
                    <td>{order.total}</td>
                    <td>
                      <a
                        onClick={() => select(order.id)}
                        href="#"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        View
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={5}>
                      <div
                        className="overflow-hidden"
                        style={selected == order.id ? show : hide}
                      >
                        <table className="table table-sm">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Prooduct Title</th>
                              <th>Quantity</th>
                              <th>Price</th>
                            </tr>
                          </thead>
                          <tbody>
                            {order.orderItems.map((o) => {
                              return (
                                <>
                                  <tr>
                                    <td>{o.id}</td>
                                    <td>{o.productTitle}</td>
                                    <td>{o.quantity}</td>
                                    <td>{o.price}</td>
                                  </tr>
                                </>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                </>
              );
            })}
          </tbody>
        </table>
      </div>
      <Paginator lastPage={lastPage} setPage={setPage} page={page} />
    </Wrapper>
  );
};

export default Orders;
