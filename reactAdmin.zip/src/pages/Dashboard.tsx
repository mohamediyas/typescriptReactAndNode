import React, { useEffect } from "react";
import Wrapper from "../components/Wrapper";
import * as c3 from "c3";
import axios from "axios";

const Dashboard = () => {
  useEffect(() => {
    const fetchData = async () => {
      const charts = c3.generate({
        bindto: "#charts",
        data: {
          x: "x",
          columns: [["x"], ["Sales"]],
          types: {
            Sales: "bar",
          },
        },
        axis: {
          x: {
            type: "timeseries",
            tick: {
              format: "%y-%m-%d",
            },
          },
        },
      });

      const { data } = await axios.get(`http://localhost:8000/api/chart`, {
        withCredentials: true,
      });

      charts.load({
        columns: [
          ["x", ...data.map((r: any) => r.date)],
          ["Sales", ...data.map((r: any) => r.sum)],
        ],
      });
    };

    fetchData();
  }, []);

  return (
    <div>
      <Wrapper>
        <h2>Daily sale</h2>
        <div id="charts"></div>
      </Wrapper>
    </div>
  );
};

export default Dashboard;
