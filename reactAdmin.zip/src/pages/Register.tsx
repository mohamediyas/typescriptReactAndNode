import React, { SyntheticEvent, useState } from "react";
import "../Login.css";
import axios from "axios";
import { Redirect } from "react-router-dom";

interface State {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  passwordConfirm: string;
}

const Register = () => {
  const [state, setState] = useState<State>({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    passwordConfirm: "",
  });

  const [redirect, setDirect] = useState(false);

  const submit = async (e: SyntheticEvent) => {
    e.preventDefault();
    const { firstName, lastName, email, password, passwordConfirm } = state;

    let data = {
      firstName,
      lastName,
      email,
      password,
      passwordConfirm,
    };

    let response = await axios.post(`http://localhost:8000/api/register`, data);

    setDirect(true);

    console.log(response);
  };

  if (redirect) {
    return <Redirect to={"/login"} />;
  }

  return (
    <div className="text-center">
      <main className="form-signin">
        <form onSubmit={submit}>
          <h1 className="h3 mb-3 fw-normal">Please sign up</h1>

          <div className="form-floating">
            <input
              type="text"
              className="form-control"
              id="floatingInput"
              placeholder="First Name"
              required
              value={state.firstName}
              onChange={(e) =>
                setState((prevState): any => ({
                  ...prevState,
                  firstName: e.target.value,
                }))
              }
            />
            <label>First Name</label>
          </div>
          <div className="form-floating">
            <input
              type="text"
              className="form-control"
              id="floatingInput"
              placeholder="Last Name"
              required
              value={state.lastName}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  lastName: e.target.value,
                }))
              }
            />
            <label>Last Name</label>
          </div>
          <div className="form-floating">
            <input
              type="email"
              className="form-control"
              id="floatingInput"
              placeholder="example@gmail.com"
              required
              value={state.email}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  email: e.target.value,
                }))
              }
            />
            <label>Email</label>
          </div>
          <div className="form-floating">
            <input
              type="password"
              className="form-control"
              id="floatingPassword"
              placeholder="Password"
              value={state.password}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  password: e.target.value,
                }))
              }
            />
            <label>Password</label>
          </div>
          <div className="form-floating">
            <input
              type="password"
              className="form-control"
              id="floatingPassword"
              placeholder="Password"
              value={state.passwordConfirm}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  passwordConfirm: e.target.value,
                }))
              }
            />
            <label>Confirm Password</label>
          </div>

          <button className="w-100 btn btn-lg btn-primary" type="submit">
            Submit
          </button>
        </form>
      </main>
    </div>
  );
};

export default Register;
