import axios from "axios";
import React, { SyntheticEvent, useEffect, useState } from "react";
import { Redirect } from "react-router-dom";
import Wrapper from "../../components/Wrapper";

interface Permission {
  id: number;
  name: string;
}

const RoleEdit = (props: any) => {
  const [permission, setPermission] = useState<Permission[]>([]);
  const [selected, setSelected] = useState([] as number[]);
  const [name, setName] = useState("");
  const [redirect, setRedirect] = useState(false);

  useEffect(() => {
    const fetchPermission = async () => {
      const response = await axios.get(
        `http://localhost:8000/api/permissions`,
        { withCredentials: true }
      );

      setPermission(response.data);

      const { data } = await axios.get(
        `http://localhost:8000/api/roles/${props.match.params.id}`,
        { withCredentials: true }
      );

      setName(data.name);

      setSelected(data.permissions.map((p: Permission) => p.id));
    };

    fetchPermission();
  }, []);

  const check = (id: number) => {
    if (selected.some((s) => s == id)) {
      setSelected(selected.filter((s) => s != id));
      return;
    }
    setSelected([...selected, id]);
  };

  const submit = async (e: SyntheticEvent) => {
    e.preventDefault();

    const { data } = await axios.put(
      `http://localhost:8000/api/roles/${props.match.params.id}`,
      {
        name,
        permissions: selected,
      },
      { withCredentials: true }
    );

    setRedirect(true);
  };

  if (redirect) {
    return <Redirect to={"/roles"} />;
  }

  return (
    <Wrapper>
      <form onSubmit={submit}>
        <div className="mb-3 mt-3 row">
          <label className="col-sm-2 col-form-label">Name</label>
          <div className="col-sm-10">
            <input
              className="form-control"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        </div>

        <div className="mb-3 row">
          <label className="col-sm-2 col-form-label">Permission</label>
          <div className="col-sm-10">
            {permission.map((permission) => {
              return (
                <div
                  key={permission.id}
                  className="form-check form-check-inline col-3"
                >
                  <input
                    value={permission.id}
                    checked={selected.some((s) => s == permission.id)}
                    onChange={() => check(permission.id)}
                    className="form-check-input"
                    type="checkbox"
                  />
                  <label className="form-check-label">{permission.name}</label>
                </div>
              );
            })}
          </div>
        </div>
        <input type="submit" />
      </form>
    </Wrapper>
  );
};

export default RoleEdit;
