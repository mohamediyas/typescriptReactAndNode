import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Wrapper from "../../components/Wrapper";

interface Role {
  id: number;
  name: string;
}

const Roles = () => {
  const [roles, setRoles] = useState<Role[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const { data } = await axios.get(`http://localhost:8000/api/roles`, {
        withCredentials: true,
      });

      setRoles(data);
    };

    fetchData();
  }, []);

  const del = async (id: number) => {
    if (window.confirm("Are you sure to delete ?")) {
      await axios.delete(`http://localhost:8000/api/roles/${id}`, {
        withCredentials: true,
      });

      setRoles(roles.filter((role) => role.id != id));
    }
  };

  return (
    <Wrapper>
      <Link to={"/roles/create"} className="btn btn-sm btn-outline-secondary">
        Add
      </Link>
      <div className="table-responsive">
        <table className="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {roles.map((role) => {
              return (
                <tr key={role.id}>
                  <td>{role.id}</td>
                  <td>{role.name}</td>
                  <td>
                    <div className="btn-group mr-2">
                      <Link
                        to={`/roles/${role.id}/edit`}
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Edit
                      </Link>
                      <a
                        href="#"
                        onClick={() => del(role.id)}
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Delete
                      </a>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Wrapper>
  );
};

export default Roles;
